
package com.mycompany.lista06;
//       Double numero1 = Double.valueOf(input1.getText());
//       Double numero2 = Double.valueOf(input2.getText());
//      
//       Double resultado = numero1 / numero2;
//       
//       lblResultado.setText((resultado).toString());;

public class Calculo {
     Double resultado;
 

    public Double getResultado() {
        return resultado;
    }

     void soma(Double numero1, Double numero2){ 
         resultado = numero1 + numero2;
     }
     void subtracao(Double numero1, Double numero2){        
         resultado = numero1 - numero2;
     }
     void multiplicacao(Double numero1, Double numero2){        
         resultado = numero1 * numero2;
     }
     void divisao(Double numero1, Double numero2){   
         resultado = numero1 / numero2;
     }
  
}
